using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("hey!:) welcome to fan simulator!");


        Console.WriteLine("choose your desired fan speed 1, 2, or 3:");
        int fanSpeed;
        while (true)
        {
            if (!int.TryParse(Console.ReadLine(), out fanSpeed) || fanSpeed < 1 || fanSpeed > 3)
            {
                Console.WriteLine("Invalid input. Please enter 1, 2, or 3:");
            }
            else
            {
                break;
            }
        }

        Console.WriteLine("do you wanna oscilliate the fan? (Y/N):");
        string choice;
        while (true)
        {
            choice = Console.ReadLine().ToUpper();
            if (choice == "Y" || choice == "N")
                break;
            Console.WriteLine("not valid. try again and enter Y or N:");
        }

        if (choice == "Y")
        {
            int rows = 10 * fanSpeed;

            for (int i = 1; i <= rows; i++)
            {
                for (int j = 1; j <= i; j++)
                {
                    Console.Write("~");
                }
                Console.WriteLine();
            }

            for (int i = rows - 1; i >= 1; i--)
            {
                for (int j = 1; j <= i; j++)
                {
                    Console.Write("~");
                }
                Console.WriteLine();
            }
        }
        else if (choice == "N")
        {
            int rows;
            int columns;

            switch (fanSpeed)
            {
                case 1:
                    rows = 9;
                    columns = 12;
                    break;
                case 2:
                    rows = 8;
                    columns = 24;
                    break;
                case 3:
                    rows = 8;
                    columns = 48;
                    break;
                default:
                    Console.WriteLine("not valid. try again and enter 1, 2, or 3.");
                    return;
            }

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)
                {
                    Console.Write("~");
                }
                Console.WriteLine();
            }
        }
    }
}
